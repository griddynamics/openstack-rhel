.. _auth:

*************************
Developer's Authorization
*************************

.. _auth_server:

Auth Server
===========

.. automodule:: swift.auth.server
    :members:
    :undoc-members:
    :show-inheritance:
