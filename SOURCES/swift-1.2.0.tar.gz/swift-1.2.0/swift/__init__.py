import gettext


__version__ = '1.2.0'
gettext.install('swift')
