# maps supported api versions to the optional features that they support
API_OPTIONS = { 'RACKSPACE' : ['IPGROUPS'],
                'OPENSTACK' : [] }