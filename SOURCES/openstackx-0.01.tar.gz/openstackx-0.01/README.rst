*DEPRECATED*

This is being deleted in favor of python-novaclient.  We are working on moving all the functionality into nova core and novaclient.

See: https://github.com/rackspace/python-novaclient