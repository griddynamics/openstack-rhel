The :mod:`nova..tests.test_xenapi` Module
==============================================================================
.. automodule:: nova..tests.test_xenapi
  :members:
  :undoc-members:
  :show-inheritance:
