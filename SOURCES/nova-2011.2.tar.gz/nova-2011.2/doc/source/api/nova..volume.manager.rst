The :mod:`nova..volume.manager` Module
==============================================================================
.. automodule:: nova..volume.manager
  :members:
  :undoc-members:
  :show-inheritance:
