The :mod:`nova..tests.api.openstack.fakes` Module
==============================================================================
.. automodule:: nova..tests.api.openstack.fakes
  :members:
  :undoc-members:
  :show-inheritance:
