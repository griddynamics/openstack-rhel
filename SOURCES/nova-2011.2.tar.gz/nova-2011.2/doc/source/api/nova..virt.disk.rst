The :mod:`nova..virt.disk` Module
==============================================================================
.. automodule:: nova..virt.disk
  :members:
  :undoc-members:
  :show-inheritance:
