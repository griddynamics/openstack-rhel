The :mod:`nova..objectstore.stored` Module
==============================================================================
.. automodule:: nova..objectstore.stored
  :members:
  :undoc-members:
  :show-inheritance:
