The :mod:`nova..tests.test_instance_types` Module
==============================================================================
.. automodule:: nova..tests.test_instance_types
  :members:
  :undoc-members:
  :show-inheritance:
