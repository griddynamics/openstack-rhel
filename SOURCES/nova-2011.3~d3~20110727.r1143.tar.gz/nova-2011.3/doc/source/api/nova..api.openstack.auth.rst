The :mod:`nova..api.openstack.auth` Module
==============================================================================
.. automodule:: nova..api.openstack.auth
  :members:
  :undoc-members:
  :show-inheritance:
