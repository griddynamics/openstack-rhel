The :mod:`nova..api.openstack.servers` Module
==============================================================================
.. automodule:: nova..api.openstack.servers
  :members:
  :undoc-members:
  :show-inheritance:
