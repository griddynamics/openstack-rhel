The :mod:`nova..api.openstack.zones` Module
==============================================================================
.. automodule:: nova..api.openstack.zones
  :members:
  :undoc-members:
  :show-inheritance:
