The :mod:`nova..objectstore.image` Module
==============================================================================
.. automodule:: nova..objectstore.image
  :members:
  :undoc-members:
  :show-inheritance:
