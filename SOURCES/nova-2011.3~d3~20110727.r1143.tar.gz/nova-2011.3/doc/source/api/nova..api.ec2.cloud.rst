The :mod:`nova..api.ec2.cloud` Module
==============================================================================
.. automodule:: nova..api.ec2.cloud
  :members:
  :undoc-members:
  :show-inheritance:
