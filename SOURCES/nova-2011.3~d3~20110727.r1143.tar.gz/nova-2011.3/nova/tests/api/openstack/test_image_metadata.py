# vim: tabstop=4 shiftwidth=4 softtabstop=4

# Copyright 2011 OpenStack LLC.
# All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import json
import stubout
import unittest
import webob
import xml.dom.minidom as minidom


from nova import flags
from nova.api import openstack
from nova import test
from nova.tests.api.openstack import fakes
import nova.wsgi


FLAGS = flags.FLAGS


class ImageMetaDataTest(test.TestCase):

    IMAGE_FIXTURES = [
        {'status': 'active',
        'name': 'image1',
        'deleted': False,
        'container_format': None,
        'checksum': None,
        'created_at': '2011-03-22T17:40:15',
        'disk_format': None,
        'updated_at': '2011-03-22T17:40:15',
        'id': '1',
        'location': 'file:///var/lib/glance/images/1',
        'is_public': True,
        'deleted_at': None,
        'properties': {
            'key1': 'value1',
            'key2': 'value2'},
        'size': 5882349},
        {'status': 'active',
        'name': 'image2',
        'deleted': False,
        'container_format': None,
        'checksum': None,
        'created_at': '2011-03-22T17:40:15',
        'disk_format': None,
        'updated_at': '2011-03-22T17:40:15',
        'id': '2',
        'location': 'file:///var/lib/glance/images/2',
        'is_public': True,
        'deleted_at': None,
        'properties': {
            'key1': 'value1',
            'key2': 'value2'},
        'size': 5882349},
        {'status': 'active',
        'name': 'image3',
        'deleted': False,
        'container_format': None,
        'checksum': None,
        'created_at': '2011-03-22T17:40:15',
        'disk_format': None,
        'updated_at': '2011-03-22T17:40:15',
        'id': '3',
        'location': 'file:///var/lib/glance/images/2',
        'is_public': True,
        'deleted_at': None,
        'properties': {},
        'size': 5882349},
        ]

    def setUp(self):
        super(ImageMetaDataTest, self).setUp()
        self.stubs = stubout.StubOutForTesting()
        self.orig_image_service = FLAGS.image_service
        FLAGS.image_service = 'nova.image.glance.GlanceImageService'
        fakes.FakeAuthManager.auth_data = {}
        fakes.FakeAuthDatabase.data = {}
        fakes.stub_out_auth(self.stubs)
        # NOTE(dprince) max out properties/metadata in image 3 for testing
        img3 = self.IMAGE_FIXTURES[2]
        for num in range(FLAGS.quota_metadata_items):
            img3['properties']['key%i' % num] = "blah"
        fakes.stub_out_glance(self.stubs, self.IMAGE_FIXTURES)

    def tearDown(self):
        self.stubs.UnsetAll()
        FLAGS.image_service = self.orig_image_service
        super(ImageMetaDataTest, self).tearDown()

    def test_index(self):
        req = webob.Request.blank('/v1.1/images/1/metadata')
        res = req.get_response(fakes.wsgi_app())
        res_dict = json.loads(res.body)
        self.assertEqual(200, res.status_int)
        expected = self.IMAGE_FIXTURES[0]['properties']
        self.assertEqual(len(expected), len(res_dict['metadata']))
        for (key, value) in res_dict['metadata'].items():
            self.assertEqual(value, res_dict['metadata'][key])

    def test_show(self):
        req = webob.Request.blank('/v1.1/images/1/metadata/key1')
        res = req.get_response(fakes.wsgi_app())
        res_dict = json.loads(res.body)
        self.assertEqual(200, res.status_int)
        self.assertTrue('meta' in res_dict)
        self.assertEqual(len(res_dict['meta']), 1)
        self.assertEqual('value1', res_dict['meta']['key1'])

    def test_show_not_found(self):
        req = webob.Request.blank('/v1.1/images/1/metadata/key9')
        res = req.get_response(fakes.wsgi_app())
        self.assertEqual(404, res.status_int)

    def test_create(self):
        req = webob.Request.blank('/v1.1/images/2/metadata')
        req.method = 'POST'
        req.body = '{"metadata": {"key9": "value9"}}'
        req.headers["content-type"] = "application/json"
        res = req.get_response(fakes.wsgi_app())

        self.assertEqual(200, res.status_int)
        actual_output = json.loads(res.body)

        expected_output = {
            'metadata': {
                'key1': 'value1',
                'key2': 'value2',
                'key9': 'value9',
            },
        }

        self.assertEqual(expected_output, actual_output)

    def test_update_all(self):
        req = webob.Request.blank('/v1.1/images/2/metadata')
        req.method = 'PUT'
        req.body = '{"metadata": {"key9": "value9"}}'
        req.headers["content-type"] = "application/json"
        res = req.get_response(fakes.wsgi_app())

        self.assertEqual(200, res.status_int)
        actual_output = json.loads(res.body)

        expected_output = {
            'metadata': {
                'key9': 'value9',
            },
        }

        self.assertEqual(expected_output, actual_output)

    def test_update_item(self):
        req = webob.Request.blank('/v1.1/images/1/metadata/key1')
        req.method = 'PUT'
        req.body = '{"meta": {"key1": "zz"}}'
        req.headers["content-type"] = "application/json"
        res = req.get_response(fakes.wsgi_app())

        self.assertEqual(200, res.status_int)
        actual_output = json.loads(res.body)
        expected_output = {
            'meta': {
                'key1': 'zz',
            },
        }
        self.assertEqual(actual_output, expected_output)

    def test_update_item_bad_body(self):
        req = webob.Request.blank('/v1.1/images/1/metadata/key1')
        req.method = 'PUT'
        req.body = '{"key1": "zz"}'
        req.headers["content-type"] = "application/json"
        res = req.get_response(fakes.wsgi_app())
        self.assertEqual(400, res.status_int)

    def test_update_item_too_many_keys(self):
        req = webob.Request.blank('/v1.1/images/1/metadata/key1')
        req.method = 'PUT'
        req.body = '{"meta": {"key1": "value1", "key2": "value2"}}'
        req.headers["content-type"] = "application/json"
        res = req.get_response(fakes.wsgi_app())
        self.assertEqual(400, res.status_int)

    def test_update_item_body_uri_mismatch(self):
        req = webob.Request.blank('/v1.1/images/1/metadata/bad')
        req.method = 'PUT'
        req.body = '{"meta": {"key1": "value1"}}'
        req.headers["content-type"] = "application/json"
        res = req.get_response(fakes.wsgi_app())
        self.assertEqual(400, res.status_int)

    def test_update_item_xml(self):
        req = webob.Request.blank('/v1.1/images/1/metadata/key1')
        req.method = 'PUT'
        req.body = '<meta key="key1">five</meta>'
        req.headers["content-type"] = "application/xml"
        res = req.get_response(fakes.wsgi_app())

        self.assertEqual(200, res.status_int)
        actual_output = json.loads(res.body)
        expected_output = {
            'meta': {
                'key1': 'five',
            },
        }
        self.assertEqual(actual_output, expected_output)

    def test_delete(self):
        req = webob.Request.blank('/v1.1/images/2/metadata/key1')
        req.method = 'DELETE'
        res = req.get_response(fakes.wsgi_app())
        self.assertEqual(204, res.status_int)
        self.assertEqual('', res.body)

    def test_delete_not_found(self):
        req = webob.Request.blank('/v1.1/images/2/metadata/blah')
        req.method = 'DELETE'
        res = req.get_response(fakes.wsgi_app())
        self.assertEqual(404, res.status_int)

    def test_too_many_metadata_items_on_create(self):
        data = {"metadata": {}}
        for num in range(FLAGS.quota_metadata_items + 1):
            data['metadata']['key%i' % num] = "blah"
        json_string = str(data).replace("\'", "\"")
        req = webob.Request.blank('/v1.1/images/2/metadata')
        req.method = 'POST'
        req.body = json_string
        req.headers["content-type"] = "application/json"
        res = req.get_response(fakes.wsgi_app())
        self.assertEqual(400, res.status_int)

    def test_too_many_metadata_items_on_put(self):
        req = webob.Request.blank('/v1.1/images/3/metadata/blah')
        req.method = 'PUT'
        req.body = '{"meta": {"blah": "blah"}}'
        req.headers["content-type"] = "application/json"
        res = req.get_response(fakes.wsgi_app())
        self.assertEqual(400, res.status_int)


class ImageMetadataXMLDeserializationTest(test.TestCase):

    deserializer = openstack.image_metadata.ImageMetadataXMLDeserializer()

    def test_create(self):
        request_body = """
        <metadata xmlns="http://docs.openstack.org/compute/api/v1.1">
            <meta key='123'>asdf</meta>
            <meta key='567'>jkl;</meta>
        </metadata>"""
        output = self.deserializer.deserialize(request_body, 'create')
        expected = {"body": {"metadata": {"123": "asdf", "567": "jkl;"}}}
        self.assertEquals(output, expected)

    def test_create_empty(self):
        request_body = """
        <metadata xmlns="http://docs.openstack.org/compute/api/v1.1"/>"""
        output = self.deserializer.deserialize(request_body, 'create')
        expected = {"body": {"metadata": {}}}
        self.assertEquals(output, expected)

    def test_update_all(self):
        request_body = """
        <metadata xmlns="http://docs.openstack.org/compute/api/v1.1">
            <meta key='123'>asdf</meta>
            <meta key='567'>jkl;</meta>
        </metadata>"""
        output = self.deserializer.deserialize(request_body, 'update_all')
        expected = {"body": {"metadata": {"123": "asdf", "567": "jkl;"}}}
        self.assertEquals(output, expected)

    def test_update(self):
        request_body = """
        <meta xmlns="http://docs.openstack.org/compute/api/v1.1"
              key='123'>asdf</meta>"""
        output = self.deserializer.deserialize(request_body, 'update')
        expected = {"body": {"meta": {"123": "asdf"}}}
        self.assertEquals(output, expected)


class ImageMetadataXMLSerializationTest(test.TestCase):

    def test_index(self):
        serializer = openstack.image_metadata.ImageMetadataXMLSerializer()
        fixture = {
            'metadata': {
                'one': 'two',
                'three': 'four',
            },
        }
        output = serializer.serialize(fixture, 'index')
        actual = minidom.parseString(output.replace("  ", ""))

        expected = minidom.parseString("""
            <metadata xmlns="http://docs.openstack.org/compute/api/v1.1">
                <meta key="three">
                    four
                </meta>
                <meta key="one">
                    two
                </meta>
            </metadata>
        """.replace("  ", ""))

        self.assertEqual(expected.toxml(), actual.toxml())

    def test_index_null(self):
        serializer = openstack.image_metadata.ImageMetadataXMLSerializer()
        fixture = {
            'metadata': {
                None: None,
            },
        }
        output = serializer.serialize(fixture, 'index')
        actual = minidom.parseString(output.replace("  ", ""))

        expected = minidom.parseString("""
            <metadata xmlns="http://docs.openstack.org/compute/api/v1.1">
                <meta key="None">
                    None
                </meta>
            </metadata>
        """.replace("  ", ""))

        self.assertEqual(expected.toxml(), actual.toxml())

    def test_index_unicode(self):
        serializer = openstack.image_metadata.ImageMetadataXMLSerializer()
        fixture = {
            'metadata': {
                u'three': u'Jos\xe9',
            },
        }
        output = serializer.serialize(fixture, 'index')
        actual = minidom.parseString(output.replace("  ", ""))

        expected = minidom.parseString(u"""
            <metadata xmlns="http://docs.openstack.org/compute/api/v1.1">
                <meta key="three">
                    Jos\xe9
                </meta>
            </metadata>
        """.encode("UTF-8").replace("  ", ""))

        self.assertEqual(expected.toxml(), actual.toxml())

    def test_show(self):
        serializer = openstack.image_metadata.ImageMetadataXMLSerializer()
        fixture = {
            'meta': {
                'one': 'two',
            },
        }
        output = serializer.serialize(fixture, 'show')
        actual = minidom.parseString(output.replace("  ", ""))

        expected = minidom.parseString("""
            <meta xmlns="http://docs.openstack.org/compute/api/v1.1" key="one">
                two
            </meta>
        """.replace("  ", ""))

        self.assertEqual(expected.toxml(), actual.toxml())

    def test_update_all(self):
        serializer = openstack.image_metadata.ImageMetadataXMLSerializer()
        fixture = {
            'metadata': {
                'key6': 'value6',
                'key4': 'value4',
            },
        }
        output = serializer.serialize(fixture, 'update_all')
        actual = minidom.parseString(output.replace("  ", ""))

        expected = minidom.parseString("""
            <metadata xmlns="http://docs.openstack.org/compute/api/v1.1">
                <meta key="key6">
                    value6
                </meta>
                <meta key="key4">
                    value4
                </meta>
            </metadata>
        """.replace("  ", ""))

        self.assertEqual(expected.toxml(), actual.toxml())

    def test_update_item(self):
        serializer = openstack.image_metadata.ImageMetadataXMLSerializer()
        fixture = {
            'meta': {
                'one': 'two',
            },
        }
        output = serializer.serialize(fixture, 'update')
        actual = minidom.parseString(output.replace("  ", ""))

        expected = minidom.parseString("""
            <meta xmlns="http://docs.openstack.org/compute/api/v1.1" key="one">
                two
            </meta>
        """.replace("  ", ""))

        self.assertEqual(expected.toxml(), actual.toxml())

    def test_create(self):
        serializer = openstack.image_metadata.ImageMetadataXMLSerializer()
        fixture = {
            'metadata': {
                'key9': 'value9',
                'key2': 'value2',
                'key1': 'value1',
            },
        }
        output = serializer.serialize(fixture, 'create')
        actual = minidom.parseString(output.replace("  ", ""))

        expected = minidom.parseString("""
            <metadata xmlns="http://docs.openstack.org/compute/api/v1.1">
                <meta key="key2">
                    value2
                </meta>
                <meta key="key9">
                    value9
                </meta>
                <meta key="key1">
                    value1
                </meta>
            </metadata>
        """.replace("  ", ""))

        self.assertEqual(expected.toxml(), actual.toxml())

    def test_delete(self):
        serializer = openstack.image_metadata.ImageMetadataXMLSerializer()
        output = serializer.serialize(None, 'delete')
        self.assertEqual(output, '')
