The :mod:`nova..fakerabbit` Module
==============================================================================
.. automodule:: nova..fakerabbit
  :members:
  :undoc-members:
  :show-inheritance:
