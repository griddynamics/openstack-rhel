The :mod:`nova..tests.db.fakes` Module
==============================================================================
.. automodule:: nova..tests.db.fakes
  :members:
  :undoc-members:
  :show-inheritance:
