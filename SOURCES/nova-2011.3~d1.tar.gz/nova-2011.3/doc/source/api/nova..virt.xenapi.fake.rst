The :mod:`nova..virt.xenapi.fake` Module
==============================================================================
.. automodule:: nova..virt.xenapi.fake
  :members:
  :undoc-members:
  :show-inheritance:
