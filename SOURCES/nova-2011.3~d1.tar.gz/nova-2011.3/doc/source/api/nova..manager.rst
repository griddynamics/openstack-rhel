The :mod:`nova..manager` Module
==============================================================================
.. automodule:: nova..manager
  :members:
  :undoc-members:
  :show-inheritance:
