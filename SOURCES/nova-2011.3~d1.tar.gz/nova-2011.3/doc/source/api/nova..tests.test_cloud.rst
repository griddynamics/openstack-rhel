The :mod:`nova..tests.test_cloud` Module
==============================================================================
.. automodule:: nova..tests.test_cloud
  :members:
  :undoc-members:
  :show-inheritance:
