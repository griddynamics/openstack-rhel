The :mod:`nova..image.s3` Module
==============================================================================
.. automodule:: nova..image.s3
  :members:
  :undoc-members:
  :show-inheritance:
