The :mod:`nova..api.openstack.images` Module
==============================================================================
.. automodule:: nova..api.openstack.images
  :members:
  :undoc-members:
  :show-inheritance:
