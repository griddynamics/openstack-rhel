The :mod:`nova..api.openstack.flavors` Module
==============================================================================
.. automodule:: nova..api.openstack.flavors
  :members:
  :undoc-members:
  :show-inheritance:
