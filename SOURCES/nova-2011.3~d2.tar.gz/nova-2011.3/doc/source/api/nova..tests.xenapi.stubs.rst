The :mod:`nova..tests.xenapi.stubs` Module
==============================================================================
.. automodule:: nova..tests.xenapi.stubs
  :members:
  :undoc-members:
  :show-inheritance:
