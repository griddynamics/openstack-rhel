The :mod:`nova..db.sqlalchemy.migrate_repo.versions.005_add_instance_metadata` Module
==============================================================================
.. automodule:: nova..db.sqlalchemy.migrate_repo.versions.005_add_instance_metadata
  :members:
  :undoc-members:
  :show-inheritance:
