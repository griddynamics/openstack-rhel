The :mod:`nova..virt.xenapi.volume_utils` Module
==============================================================================
.. automodule:: nova..virt.xenapi.volume_utils
  :members:
  :undoc-members:
  :show-inheritance:
